#define PNG_USER_PRIVATEBUILD "Skia build; no MNG features"
#define PNG_USER_DLLFNAME_POSTFIX "Sk"
#define PNG_NO_MNG_FEATURES
#define PNG_NO_READ_GAMMA
